public class Basket {
    Product product;
    Category category;
    public Basket(String name, double price, double rating, String names) {
        product.getName();
        product.getPrice();
        product.getRating();
        category.getNames();
    }
    public static Basket purchasedGoods () {
        return new Basket("HP Spectre x360", 141999, 5.0, "notebook");
    }
}
