
/*▸ Создать класс Товар, имеющий переменные имя, цена, рейтинг
        ▸ Создать класс Категория, имеющий переменные имя и массив товаров
        ▸ Создать несколько объектов класса Категория
        ▸ Создать класс Basket, содержащий массив купленных товаров
        ▸ Создать класс User, содержащий логин, пароль и объект класса Basket
        ▸ Создать объект класса User*/

public class Score {
    public static void main(String[] args) {
        User user = new User("VasyaPupkin","Vasya$co12%ol");
        //System.out.println(user.setLoginAndPassword());
    }
}